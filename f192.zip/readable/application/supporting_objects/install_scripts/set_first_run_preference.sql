begin
    eba_cust_fw.set_preference_value( p_preference_name => 'FIRST_RUN', p_preference_value => 'YES' );
end;