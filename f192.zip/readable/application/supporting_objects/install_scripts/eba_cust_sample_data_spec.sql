create or replace package eba_cust_sample_data as

    -------------------------------------------------------------------------
    procedure create_sample_data;
    
    -------------------------------------------------------------------------
    procedure remove_sample_data;
        
end eba_cust_sample_data;
/
show errors
