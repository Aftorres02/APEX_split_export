alter table eba_cust_customers add reference_phase_id number;
