alter table eba_cust_customers add support_id            varchar2(50);

alter table eba_cust_customers add party_id            varchar2(50);

alter table eba_cust_customers add parent_party_id     varchar2(50);

alter table eba_cust_customers add party_name          varchar2(255);

alter table eba_cust_customers add partent_party_name  varchar2(255);
