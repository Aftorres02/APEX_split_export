insert into eba_cust_feedback_types (id, type) values (1, 'General Comment');
insert into eba_cust_feedback_types (id, type) values (2, 'Enhancement Request');
insert into eba_cust_feedback_types (id, type) values (3, 'Bug');
commit;