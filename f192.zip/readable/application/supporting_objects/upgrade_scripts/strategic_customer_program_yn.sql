alter table eba_cust_customers add strategic_customer_program_yn varchar2(1) default 'N'
/