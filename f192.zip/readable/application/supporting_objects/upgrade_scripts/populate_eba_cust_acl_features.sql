insert into eba_cust_acl_features (authorization_name, feature, access_level_id)
  values ('EDIT_COMPETITORS','Specify what access level is required to maintain competitors.',2);
insert into eba_cust_acl_features (authorization_name, feature, access_level_id)
  values ('VIEW_COMPETITORS','Specify what level can view competiors, and add them to customers.',2);
commit;
