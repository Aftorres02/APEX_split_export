alter table eba_cust_contacts add facebook varchar2(4000);
alter table eba_cust_contacts add linkedin varchar2(4000);
alter table eba_cust_contacts add twitter  varchar2(4000);

